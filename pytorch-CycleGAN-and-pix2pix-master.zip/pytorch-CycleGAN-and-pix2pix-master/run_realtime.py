import os
from options.test_options import TestOptions
from data import create_dataset
from models import create_model

import cv2
import numpy as np
from PIL import Image
import torch
import argparse
import torchvision
import torch.nn as nn
from torchvision import transforms
import copy

# Reference: https://www.pyimagesearch.com/2014/11/17/non-maximum-suppression-object-detection-python/
# Felzenszwalb et al.
def non_max_suppression_slow(boxes, overlapThresh):
	# if there are no boxes, return an empty list
	if len(boxes) == 0:
		return []
	# initialize the list of picked indexes
	pick = []
	# grab the coordinates of the bounding boxes
	x1 = boxes[:,0]
	y1 = boxes[:,1]
	x2 = boxes[:,2]
	y2 = boxes[:,3]
	# compute the area of the bounding boxes and sort the bounding
	# boxes by the bottom-right y-coordinate of the bounding box
	area = (x2 - x1 + 1) * (y2 - y1 + 1)
	idxs = np.argsort(y2)

	# keep looping while some indexes still remain in the indexes
	# list
	while len(idxs) > 0:
		# grab the last index in the indexes list, add the index
		# value to the list of picked indexes, then initialize
		# the suppression list (i.e. indexes that will be deleted)
		# using the last index
		last = len(idxs) - 1
		i = idxs[last]
		pick.append(i)
		suppress = [last]

		# loop over all indexes in the indexes list
		for pos in range(0, last):
			# grab the current index
			j = idxs[pos]
			# find the largest (x, y) coordinates for the start of
			# the bounding box and the smallest (x, y) coordinates
			# for the end of the bounding box
			xx1 = max(x1[i], x1[j])
			yy1 = max(y1[i], y1[j])
			xx2 = min(x2[i], x2[j])
			yy2 = min(y2[i], y2[j])
			# compute the width and height of the bounding box
			w = max(0, xx2 - xx1 + 1)
			h = max(0, yy2 - yy1 + 1)
			# compute the ratio of overlap between the computed
			# bounding box and the bounding box in the area list
			overlap = float(w * h) / area[j]
			# if there is sufficient overlap, suppress the
			# current bounding box
			if overlap > overlapThresh:
				suppress.append(pos)
		# delete all indexes from the index list that are in the
		# suppression list
		idxs = np.delete(idxs, suppress)
	# return only the bounding boxes that were picked
	return boxes[pick]

def detectAndDisplay(frame, face_cascade, padding = 10):
    frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    frame_gray = cv2.equalizeHist(frame_gray)
    #-- Detect faces
    faces = face_cascade.detectMultiScale(frame_gray)

    #perform non-maximum suppression on the bounding boxes
    #faces = non_max_suppression_slow(faces, 0.3)
    pred_frame = None
    faceROI = None

    if len(faces) > 0:
        for (x,y,w,h) in faces:
            center = (x + w//2, y + h//2)
            original = copy.deepcopy(frame)
            pred_frame = cv2.rectangle(frame, (x-padding, y-padding), (x+w+padding, y+h+padding), (255, 0, 0), 2)
            faceROI = frame[y : y+h, x :x+w]
        return original, pred_frame, faceROI
    else:
        return frame, frame, frame
        
#Loading our Classifier
### Load Model

def main():
    parser = argparse.ArgumentParser()
    # Required parameters
    parser.add_argument("--face_cascade_name", type=str, default="haarcascade_frontalface_default.xml",
                            help="from Nasked to Masked", required=True)
    parser.add_argument("--netA", type=str, default="latest_net_G_A.pth",
                        help="from Nasked to Masked")
    parser.add_argument("--netB", type=str, default="latest_net_G_A.pth",
                        help="from Masked to Naked")
    parser.add_argument("--classifier", type=str, default="binary_resnet18_ft.pt",
                        help="Binary classifier for masked/naked face")

    args = parser.parse_args()

    data_transforms = transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])

    root_path = os.getcwd()
    model_path = os.path.join(root_path, "pretrained", args.classifier)
    class_labels = ["Naked Face", "Masked Face"]

    classifier = torch.load(model_path)
    classifier.cuda()

    face_cascade = cv2.CascadeClassifier(args.face_cascade_name)
    #-- 1. Load the cascades
    if face_cascade == None:
        try:
            print("Inside try method")
            face_cascade.load(cv2.samples.findFile(args.face_cascade_name))
        except:
            print('--(!)Error loading face cascade')
            exit(0)

    #Loading our CycleGAN
    model_path = os.path.join(root_path, "pretrained", args.netA)
    model_netA = torch.load(model_path)     # create a model given opt.model and other options

    model_path = os.path.join(root_path, "pretrained", args.netB)
    model_netB = torch.load(model_path)               # regular setup: load and print networks; create schedulers

    #Testing it
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cap.isOpened:
        print('--(!)Error opening video capture')
        exit(0)

    counter = 0
    while(cap.isOpened()):
        # capture frame-by-frame
        ret, img = cap.read()
        if img is None:
            print('--(!) No captured frame -- Break!')
            break
        if img is not None:
            original, frame, faceROI = detectAndDisplay(img, face_cascade, padding = 10)
            if (frame is not None and faceROI is not None):
                # You may need to convert the color.
                img = cv2.cvtColor(original, cv2.COLOR_BGR2RGB)
                im_pil = Image.fromarray(img)

                with torch.no_grad():
                    input_ = data_transforms(im_pil)
                    input_img = torch.Tensor(input_).unsqueeze(0).cuda()
                    out = classifier(input_img)
                    pred_y = torch.argmax(out, dim=-1).cpu()
                    label = class_labels[pred_y]

                # inserting text on frame
                font = cv2.FONT_HERSHEY_SIMPLEX
                cv2.putText(frame, label, (50, 50), font, 1, (0, 255, 255), 2, cv2.LINE_4)

                #Display detected face
                cv2.imshow('Capture - Mask detection', frame)

                #CycleGAN
                if label == "Naked Face":
                    img_name = "naked_" + str(counter) + ".png"
                    path_save = os.path.join("datasets", "mine", "testA", img_name)
                    im_pil.save(path_save)
                else:
                    img_name = "masked_" + str(counter) + ".png"
                    path_save = os.path.join("datasets", "mine", "testB", img_name)
                    im_pil.save(path_save)

                counter += 1
                if cv2.waitKey(10) == 27:
                    break

    cap.release()
    cv2.destroyAllWindows()
    cv2.waitKey(1)


if __name__ == "__main__":
    main()
